﻿<#
    Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.
    THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
    INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
    We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to reproduce and distribute the object
    code form of the Sample Code, provided that. You agree: (i) to not use Our name, logo, or trademarks to market Your software
    product in which the Sample Code is embedded; (ii) to include a valid copyright notice on Your software product in which the
    Sample Code is embedded; and (iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or
    lawsuits, including attorneys’ fees, that arise or result from the use or distribution of the Sample Code.

    .Synopsis
        Retrieve FedAuth cookie from SharePoint federated with ADFS (endpoints can be modified to work with different STS's).
        To save the cookie use: Out-File "C:\Temp\fedauth.json"
        To restore a saved cookie for API operations use: $fedAuthCookie = [net.cookie]((Get-Content "C:\Temp\fedauth.json") | ConvertFrom-Json)
        Use -OutputType '$Global.FedAuthCookie' to reuse in same PS session.

    .Examples 

        # Get a FedAuth cookie from the "/adfs/services/trust/13/usernamemixed" endpoint using provided username/password. Pipe FedAuth cookie JSON to file.
        .\Get-FedAuthCookie.ps1 -StsUrl "https://adfs.contoso.com" -WebUrl "https://sps2013.contoso.com" -AppliesTo "urn:sps2013:sharepoint" -Username "USERNAME" -Password "PASSWORD" | Out-File "C:\Temp\fedauth.json"

        # Get a FedAuth cookie from the "/adfs/services/trust/13/windowstransport" endpoint using integrated identity (identity running script). Pipe FedAuth cookie JSON to file.
        .\Get-FedAuthCookie.ps1 -StsUrl "https://adfs.contoso.com" -WebUrl "https://sps2013.contoso.com" -AppliesTo "urn:sps2013:sharepoint" -Integrated | Out-File "C:\Temp\fedauth.json"

        # Get a FedAuth cookie from the "/adfs/services/trust/13/windowstransport" endpoint using integrated identity (identity running script). Returns cookie value only.
        .\Get-FedAuthCookie.ps1 -StsUrl "https://adfs.contoso.com" -WebUrl "https://sps2013.contoso.com" -AppliesTo "urn:sps2013:sharepoint" -Integrated -OutputType Value

        # Get a FedAuth cookie from the "/adfs/services/trust/2005/windowstransport" endpoint using integrated identity (identity running script). Sets global variable only.
        .\Get-FedAuthCookie.ps1 -StsUrl "https://adfs.contoso.com" -WebUrl "https://sps2013.contoso.com" -AppliesTo "urn:sps2013:sharepoint" -TrustVersion WSTrustFeb2005 -Integrated -OutputType '$Global.FedAuthCookie'

    .Author
        Brent Person
        Vitaly Lyamin
#>

[CmdletBinding()]
Param(
[Parameter(Mandatory=$true)]
[ValidateNotNullOrEmpty()]
[string]$StsUrl,
[Parameter(Mandatory=$false)]
[ValidateNotNullOrEmpty()]
[string]$WebUrl,
[Parameter(Mandatory=$false)]
[ValidateNotNullOrEmpty()]
[string]$AppliesTo,
[Parameter(Mandatory=$false, ParameterSetName='UsernamePassword')]
[string]$Username,
[Parameter(Mandatory=$false, ParameterSetName='UsernamePassword')]
[string]$Password,
[Parameter(Mandatory=$false)]
[ValidateSet("WSTrustFeb2005", "WSTrust13")]
[string]$TrustVersion = "WSTrust13",
[Parameter(Mandatory=$false, ParameterSetName='Integrated')]
[switch]$Integrated,
[Parameter(Mandatory=$false)]
[ValidateSet("JSON", "Value", "`$Global.FedAuthCookie")]
[string]$OutputType = "JSON"
)

Add-Type -AssemblyName 'System.ServiceModel, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'
Add-Type -AssemblyName 'System.IdentityModel, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'

#region CONFIG
$Config = @{
    ServiceEndpoint = "/adfs/services/trust/13/usernamemixed"
    SecurityMode = [System.ServiceModel.SecurityMode]::TransportWithMessageCredential
    MessageCredentialType = [System.ServiceModel.MessageCredentialType]::UserName
    TransportCredentialType = [System.ServiceModel.HttpClientCredentialType]::None
    TrustVersion = [System.ServiceModel.Security.TrustVersion]::WSTrust13
    IssueAction = "http://docs.oasis-open.org/ws-sx/ws-trust/200512/RST/Issue"
    IssueRequestType = "http://docs.oasis-open.org/ws-sx/ws-trust/200512/Issue"
    MessageVersion = [System.ServiceModel.Channels.MessageVersion]::Default
    Serializer = "System.IdentityModel.Protocols.WSTrust.WSTrust13RequestSerializer"
    ClientCredential = [System.Net.CredentialCache]::DefaultNetworkCredentials
    TrustUri = [uri]"{0}/_trust" -f $WebUrl.TrimEnd("/")
    AuthenticateUrl = "{0}/_layouts/15/Authenticate.aspx" -f $WebUrl.TrimEnd("/")
}

if ($TrustVersion -ieq "WSTrustFeb2005")
{
    $Config.ServiceEndpoint = "/adfs/services/trust/2005/usernamemixed"
    $Config.TrustVersion = [System.ServiceModel.Security.TrustVersion]::WSTrustFeb2005
    $Config.IssueAction = "http://schemas.xmlsoap.org/ws/2005/02/trust/RST/Issue"
    $Config.IssueRequestType = "http://schemas.xmlsoap.org/ws/2005/02/trust/Issue"
    $Config.Serializer = "System.IdentityModel.Protocols.WSTrust.WSTrustFeb2005RequestSerializer"
}

if ($Integrated.IsPresent)
{
    $Config.ServiceEndpoint = $Config.ServiceEndpoint.Replace("usernamemixed", "windowstransport")
    $Config.SecurityMode = [System.ServiceModel.SecurityMode]::Transport
    $Config.MessageCredentialType = [System.ServiceModel.MessageCredentialType]::Windows
    $Config.TransportCredentialType = [System.ServiceModel.HttpClientCredentialType]::Windows
}

$StsUrl = "{0}{1}" -f $StsUrl.TrimEnd("/"), $Config.ServiceEndpoint
#endregion CONFIG

#region GET TOKEN
# Bindings
$binding = New-Object System.ServiceModel.WSHttpBinding($Config.SecurityMode)
$binding.Security.Message.EstablishSecurityContext = $false
$binding.Security.Message.ClientCredentialType = $Config.MessageCredentialType
$binding.Security.Transport.ClientCredentialType = $Config.TransportCredentialType


# Request security token
$requestSecurityToken = New-Object System.IdentityModel.Protocols.WSTrust.RequestSecurityToken
$requestSecurityToken.RequestType = $Config.IssueRequestType
$requestSecurityToken.AppliesTo = New-Object System.IdentityModel.Protocols.WSTrust.EndpointReference($AppliesTo)
$requestSecurityToken.KeyType = [System.IdentityModel.Protocols.WSTrust.KeyTypes]::Bearer

# Message
$serializer = New-Object ($Config.Serializer)
$serializationContext = New-Object System.IdentityModel.Protocols.WSTrust.WSTrustSerializationContext
$writer = New-Object System.ServiceModel.Security.WSTrustRequestBodyWriter($requestSecurityToken, $serializer, $serializationContext)
$requestMessage = [System.ServiceModel.Channels.Message]::CreateMessage($Config.MessageVersion, $Config.IssueAction, $writer)

# Factory
$endpoint = New-Object System.ServiceModel.EndpointAddress($StsUrl)
$factory = New-Object System.ServiceModel.Security.WSTrustChannelFactory($binding, $endpoint)
$factory.TrustVersion = $Config.TrustVersion
$factory.Credentials.UserName.UserName = $Username
$factory.Credentials.UserName.Password = $Password
$factory.Credentials.Windows.ClientCredential = $Config.ClientCredential
$factory.Credentials.Windows.AllowedImpersonationLevel = [System.Security.Principal.TokenImpersonationLevel]::Impersonation
$channel = $factory.CreateChannel()

$token = $channel.Issue($requestMessage)

$reader = $token.GetReaderAtBodyContents()
$tokenXml = $reader.ReadOuterXml()
$reader.Dispose()
#endregion GET TOKEN

#region GET FEDAUTH COOKIE
$body = "wa=wsignin1.0&wresult={0}&wctx={1}" -f [uri]::EscapeDataString($tokenXml), [uri]::EscapeDataString($Config.AuthenticateUrl)
$cookieContainer = New-Object System.Net.CookieContainer
$bodyBytes = [Text.Encoding]::UTF8.GetBytes($body)
$request = [System.Net.HttpWebRequest]::CreateHttp($Config.TrustUri)
$request.Method = 'POST'
$request.CookieContainer = $cookieContainer
$request.ContentType = "application/x-www-form-urlencoded"
$request.AllowAutoRedirect = $false
$stream = $request.GetRequestStream()
$stream.Write($bodyBytes, 0, $bodyBytes.Length)
$response = $request.GetResponse()
$stream.Dispose()
$response.Dispose()

$fedAuthCookie = $cookieContainer.GetCookies([uri]$WebUrl)["FedAuth"]
#endregion GET FEDAUTH COOKIE

#region OUTPUT
if ($OutputType -ieq "JSON")
{
    Write-Output (($fedAuthCookie | ConvertTo-Json) -replace '"Timestamp.*,', '')
}
elseif ($OutputType -ieq "Value")
{
    Write-Output $fedAuthCookie.Value
}
else
{
    $Global:FedAuthCookie = $fedAuthCookie
}
#endregion OUTPUT