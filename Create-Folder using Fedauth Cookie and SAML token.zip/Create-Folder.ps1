﻿# .\Get-FedAuthCookie.ps1 -StsUrl "https://adfs.campperson.com" -WebUrl "https://sps2013.campperson.com" -AppliesTo "urn:sps2013:sharepoint" -Integrated | Out-File "C:\Temp\fedauth.json"

$fedAuthCookie = [net.cookie]((Get-Content "C:\Temp\fedauth.txt") | ConvertFrom-Json)
$folderpath = "Shared Documents"
$folderName = "Testing Folder Creation4"

#region GET FORMDIGESTVALUE
$session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$session.Cookies.Add($fedAuthCookie)
 
$response = Invoke-RestMethod -Uri "$webUrl/_api/contextinfo" -Method Post -WebSession $session -Headers @{"X-FORMS_BASED_AUTH_ACCEPTED" = "f"; "accept" = "application/json; odata=verbose"}
$formDigest = $response.d.GetContextWebInformation.FormDigestValue

#endregion GET FORMDIGESTVALUE

#region CREATE FOLDER
$params = @{}
$params.Headers = @{"X-FORMS_BASED_AUTH_ACCEPTED" = "f"; "accept" = "application/json; odata=verbose"; "X-RequestDigest" = $formDigest}
$params.Uri = "$webUrl/_api/web/getFolderByServerRelativeURL('" + $folderPath + "')/folders"
$params.Body = (ConvertTo-Json @{
        __metadata = @{ type= "SP.Folder" }
        ServerRelativeUrl = $folderName
    })
$params.Method = "POST"
$params.WebSession = $session

$response = Invoke-RestMethod @params -ContentType "application/json;odata=verbose"
#endregion CREATE FOLDER